# Custom radio button CSS only

A Pen created on CodePen.io. Original URL: [https://codepen.io/manabox/pen/raQmpL](https://codepen.io/manabox/pen/raQmpL).

Custom and fancy checkbox style with automatic fallback for older browsers.

Forked from [Giandomenico Pastore](http://codepen.io/giando110188/)'s Pen [Custom checkbox CSS only](http://codepen.io/giando110188/pen/zxoboB/).

Forked from [Giandomenico Pastore](http://codepen.io/giando110188/)'s Pen [Custom checkbox CSS only](http://codepen.io/giando110188/pen/zxoboB/).